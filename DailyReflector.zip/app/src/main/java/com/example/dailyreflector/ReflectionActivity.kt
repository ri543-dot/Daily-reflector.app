package com.example.dailyreflector

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button

class ReflectionActivity : AppCompatActivity() {
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // reuse layout for simplicity

        val recycler = findViewById<RecyclerView>(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)

        val tasks = TaskStore.loadTasks(this)
        adapter = TaskAdapter(this, tasks)
        recycler.adapter = adapter

        findViewById<Button>(R.id.exportBtn).setOnClickListener {
            TaskStore.appendDailyReflection(this, tasks)
            Utils.showToast(this, "Saved reflection to local log")
            TaskStore.saveTasks(this, tasks)
            finish()
        }

        findViewById<Button>(R.id.openReflection).setOnClickListener {
            // mark saved
            TaskStore.appendDailyReflection(this, tasks)
            TaskStore.saveTasks(this, tasks)
            Utils.showToast(this, "Saved and closed")
            finish()
        }
    }
}
