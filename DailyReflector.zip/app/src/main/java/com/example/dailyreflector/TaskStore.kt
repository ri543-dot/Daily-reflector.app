package com.example.dailyreflector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object TaskStore {
    private const val KEY = "tasks_json"
    private const val LOGNAME = "daily_reflections.log"

    fun defaultTasks(): MutableList<Task> {
        return mutableListOf(
            Task("Sleep", "6 hours"),
            Task("Lunch/Supper & prep", "1.5 hours"),
            Task("Earn money", "1 hour"),
            Task("Assignments", "1 hour"),
            Task("Coding exercises", "1 hour"),
            Task("Reading", "1 hour"),
            Task("Clubs/Friends/Family", "2 hours"),
            Task("Class & prep", "1 hour 20 minutes"),
            Task("Broken-down learning", "3 hours 10 minutes")
        )
    }

    fun loadTasks(ctx: Context): MutableList<Task> {
        val prefs = ctx.getSharedPreferences("daily_prefs", Context.MODE_PRIVATE)
        val json = prefs.getString(KEY, null) ?: return defaultTasks()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<Task>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Task(o.getString("title"), o.getString("duration")).apply {
                    done = o.optBoolean("done", false)
                    note = o.optString("note", null)
                })
            }
            list
        } catch (e: Exception) {
            defaultTasks()
        }
    }

    fun saveTasks(ctx: Context, tasks: List<Task>) {
        val arr = JSONArray()
        for (t in tasks) {
            val o = JSONObject()
            o.put("title", t.title)
            o.put("duration", t.duration)
            o.put("done", t.done)
            o.put("note", t.note ?: "")
            arr.put(o)
        }
        ctx.getSharedPreferences("daily_prefs", Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun exportLogToFile(ctx: Context): File {
        val file = File(ctx.filesDir, LOGNAME)
        return file
    }

    fun appendDailyReflection(ctx: Context, tasks: List<Task>) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val header = "--- ${'$'}{sdf.format(Date())} ---\n"
        val sb = StringBuilder().append(header)
        for (t in tasks) {
            sb.append("${'$'}{t.title}: ${'$'}{if (t.done) "DONE" else "NOT DONE"}")
            if (!t.note.isNullOrBlank()) sb.append(" — Note: ${'$'}{t.note}")
            sb.append("\n")
        }
        sb.append("\n")
        ctx.openFileOutput(LOGNAME, Context.MODE_APPEND).use { fos ->
            fos.write(sb.toString().toByteArray())
        }
    }

    fun resetTasksForNewDay(ctx: Context) {
        val tasks = loadTasks(ctx)
        for (t in tasks) {
            t.done = false
            t.note = null
        }
        saveTasks(ctx, tasks)
    }
}
