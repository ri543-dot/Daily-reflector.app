package com.example.dailyreflector

data class Task(
    val title: String,
    val duration: String,
    var done: Boolean = false,
    var note: String? = null
)
