package com.example.dailyreflector

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(private val ctx: Context, private val tasks: MutableList<Task>) : RecyclerView.Adapter<TaskAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cb: CheckBox = v.findViewById(R.id.checkBox)
        val title: TextView = v.findViewById(R.id.taskTitle)
        val noteBtn: ImageButton = v.findViewById(R.id.noteBtn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = tasks[position]
        holder.title.text = t.title + " (${t.duration})"
        holder.cb.isChecked = t.done
        holder.cb.setOnCheckedChangeListener { _, isChecked ->
            t.done = isChecked
            TaskStore.saveTasks(ctx, tasks)
        }
        holder.noteBtn.setOnClickListener {
            val input = android.widget.EditText(ctx)
            input.setText(t.note ?: "")
            AlertDialog.Builder(ctx)
                .setTitle("Add note for: ${t.title}")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    t.note = input.text.toString()
                    TaskStore.saveTasks(ctx, tasks)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun getItemCount(): Int = tasks.size
}
