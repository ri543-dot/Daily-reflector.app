        DailyReflector - Offline Daily Checklist App

        Files in this ZIP are a minimal Android Studio project you can open/import.

        How to use:
1. Open Android Studio -> Import project (Gradle) or create new project and replace files.
2. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
3. Install the generated APK on your Redmi 14C and grant notification permission.

Notes:
- No INTERNET permission is included; app is offline-only.
- Log file is stored in internal storage: files/daily_reflections.log
